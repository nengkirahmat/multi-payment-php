-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jun 2025 pada 15.52
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_multipayment`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `website_id` int(11) NOT NULL,
  `payment_gateway_code` varchar(50) NOT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`config`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `website_id`, `payment_gateway_code`, `config`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'xendit', '{\"api_key\": \"xnd_development_P4qDfOss0OCpl8RtKrROHjaQYNCk9dN5lSfk+R1l9Wbe+rSiCwZ3jw==\", \"callback_token\": \"your_xendit_callback_token\", \"base_url\": \"https://api.xendit.co\"}', 1, '2025-06-05 08:16:06', '2025-06-05 08:17:25'),
(2, 1, 'midtrans', '{\"server_key\": \"SB-Mid-server-rgN1nfmXsuTYTxZ_UzXZg2H4\", \"client_key\": \"SB-Mid-client-FCKy9Ik5MzCmTs-O\", \"base_url\": \"https://api.sandbox.midtrans.com\", \"is_production\": \"false\"}', 1, '2025-06-05 08:16:06', '2025-06-06 23:54:08'),
(4, 1, 'tripay', '{\"base_url\":\"https://tripay.co.id/api-sandbox\",\"api_key\":\"DEV-J9qvlftW9juc2AJOYgdSf8rUGJAURLRlvosr9OXF\",\"private_key\":\"XhkWV-x8moC-FswfH-itxo3-HmOdp\",\"merchant_code\":\"T24698\"}', 1, '2025-06-07 09:23:35', '2025-06-07 09:38:17'),
(5, 1, 'stripe', '{\r\n    \"secret_key\": \"sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\",\r\n    \"base_url\": \"https://api.stripe.com\"\r\n}', 1, '2025-06-08 16:35:47', '2025-06-08 16:35:47'),
(6, 1, 'doku', '{\n    \"client_id\": \"BRN-0205-1749445149430\",\n    \"secret_key\": \"SK-9rhMiJyxGlbbVFp8p3YX\",\n    \"base_url\": \"https://api-sandbox.doku.com\"\n}', 1, '2025-06-08 16:35:47', '2025-06-09 05:05:24'),
(7, 1, 'faspay', '{\r\n    \"user_id\": \"your-faspay-user-id\",\r\n    \"password\": \"your-faspay-api-password\",\r\n    \"base_url\": \"https://debit-sandbox.faspay.co.id\"\r\n}', 1, '2025-06-08 16:35:47', '2025-06-08 16:35:47');

-- --------------------------------------------------------

--
-- Struktur dari tabel `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_gateway_id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `payment_gateway_id`, `code`, `label`, `image`, `is_active`, `config`) VALUES
(1, 1, 'dana', 'DANA', NULL, 1, '{\"endpoint\":\"/ewallets/charges\",\"success_redirect_url\": \"https://localhost/payment/xendit/success\"}'),
(2, 1, 'qris', 'QRIS', NULL, 1, '{\"endpoint\":\"/qr_codes\",\"callback_url\": \"https://localhost.com/payment/xendit/callback\"}'),
(3, 1, 'invoice', 'INVOICE', NULL, 1, '{\"endpoint\":\"/v2/invoices\",\"success_redirect_url\": \"https://localhost.com/payment/xendit/success\"}'),
(4, 2, 'gopay', 'GOPAY', NULL, 1, '{\"endpoint\":\"/v2/charge\"}'),
(5, 2, 'qris', 'QRIS', NULL, 1, '{\"endpoint\":\"/v2/charge\"}'),
(6, 2, 'invoice', 'INVOICE', NULL, 1, '{\"endpoint\":\"/v1/invoices\"}'),
(7, 1, 'ovo', 'OVO', NULL, 1, '{\"endpoint\":\"/ewallets/charges\",\"success_redirect_url\": \"https://localhost/payment/xendit/success\",\"failure_redirect_url\":\"https://localhost/payment/xendit/failed\"}'),
(8, 2, 'payment_link', 'Payment Link', NULL, 1, '{\"endpoint\":\"/v1/payment-links\"}'),
(9, 2, 'shopeepay', 'ShopeePay', NULL, 1, '{\"endpoint\":\"/v2/charge\"}'),
(10, 4, 'qris', 'QRIS', NULL, 1, '{\"endpoint\":\"/transaction/create\"}'),
(11, 5, 'payment_intent', 'Payment Intent', NULL, 1, '{\r\n    \"endpoint\": \"/v1/payment_intents\"\r\n}'),
(12, 6, 'bca_va', 'Virtual Akun BCA', NULL, 1, '{\n    \"endpoint\": \"/bca-virtual-account/v2/payment-code\"\n}'),
(13, 7, 'checkout', 'Checkout', NULL, 1, '{\"endpoint\": \"/ewallet\"}'),
(14, 6, 'checkout', 'Checkout Payment', NULL, 1, '{\"endpoint\":\"/checkout/v1/payment\"}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `website_id` int(11) NOT NULL,
  `invoice_code` varchar(100) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `payment_gateway_code` varchar(50) NOT NULL,
  `payment_method_code` varchar(50) NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaction_payments`
--

CREATE TABLE `transaction_payments` (
  `id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `external_id` varchar(100) NOT NULL,
  `gateway_response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`gateway_response`)),
  `status` varchar(50) NOT NULL,
  `paid_at` datetime DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  `callback_url` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `website_id` (`website_id`,`payment_gateway_code`);

--
-- Indeks untuk tabel `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_payment_methods_gateway` (`payment_gateway_id`);

--
-- Indeks untuk tabel `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_code` (`invoice_code`);

--
-- Indeks untuk tabel `transaction_payments`
--
ALTER TABLE `transaction_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction_id` (`transaction_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transaction_payments`
--
ALTER TABLE `transaction_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `fk_payment_methods_gateway` FOREIGN KEY (`payment_gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaction_payments`
--
ALTER TABLE `transaction_payments`
  ADD CONSTRAINT `transaction_payments_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
